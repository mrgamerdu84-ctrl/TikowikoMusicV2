/* ================= Tikowiko — prototype interactif ================= */

const IC = {
  video: '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2.5" y="5" width="14" height="14" rx="2.5"/><path d="M17 12l4.5-3v9L17 15z" fill="currentColor" stroke="none"/></svg>',
  game: '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M7 12H3M5 10v4"/><circle cx="18" cy="11" r="1.3" fill="currentColor"/><circle cx="15" cy="14" r="1.3" fill="currentColor"/><rect x="1.5" y="6.5" width="21" height="11" rx="5.5"/></svg>',
  mic: '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="9" y="2.5" width="6" height="11" rx="3" fill="currentColor" stroke="none"/><path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21"/></svg>',
  call: '<svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><path d="M6.6 3h3l1.6 4-2.1 1.6a11 11 0 0 0 5.3 5.3l1.6-2.1 4 1.6v3A2 2 0 0 1 18 18.4 15.4 15.4 0 0 1 5.6 6 2 2 0 0 1 6.6 3z"/></svg>',
  gps: '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 21s7-6.2 7-11a7 7 0 1 0-14 0c0 4.8 7 11 7 11z"/><circle cx="12" cy="10" r="2.4" fill="currentColor"/></svg>',
  notif: '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 9a6 6 0 1 1 12 0c0 5 2 6 2 6H4s2-1 2-6z"/><path d="M10 19a2.2 2.2 0 0 0 4 0"/></svg>'
};

/* Réglages par défaut = comportement décrit par l'utilisateur */
const SOURCES = [
  { id: 'video', label: 'Vidéo', app: 'YouTube, TikTok, Netflix', rule: 'pause', dur: 4200 },
  { id: 'game',  label: 'Jeu',   app: 'Jeux avec son',           rule: 'keep',  dur: 3600 },
  { id: 'mic',   label: 'Micro', app: 'Mémo vocal, visio',  rule: 'pause', dur: 3400 },
  { id: 'call',  label: 'Appel', app: 'Téléphone, WhatsApp',      rule: 'pause', dur: 3800 },
  { id: 'gps',   label: 'GPS',   app: 'Maps, Waze',          rule: 'duck',  dur: 2800 },
  { id: 'notif', label: 'Notification', app: 'Message, alerte',   rule: 'duck',  dur: 2000 }
];

const ACTS = {
  pause: { name: 'Pause',          led: 'led-pause', vol: 78, state: 'Pause · interruption', short: 'Pause' },
  duck:  { name: 'Volume baissé',  led: 'led-duck',  vol: 22, state: 'Lecture · volume baissé 22 %', short: 'Volume baissé' },
  keep:  { name: 'Lecture maintenue', led: '',       vol: 78, state: 'Lecture · volume 78 %', short: 'Maintien' }
};

const $ = (s) => document.querySelector(s);

/* Profils : un preset applique toutes les règles d'un coup */
const PROFILES = {
  maison:    { label: 'Maison',    ic: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 11l8-6 8 6v8a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1z"/></svg>', rules: { video: 'pause', game: 'keep',  mic: 'pause', call: 'pause', gps: 'duck', notif: 'duck' } },
  ecouteurs: { label: 'Écouteurs', ic: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 16v-5a6 6 0 0 1 12 0v5"/><rect x="3" y="14" width="4" height="6" rx="2" fill="currentColor" stroke="none"/><rect x="17" y="14" width="4" height="6" rx="2" fill="currentColor" stroke="none"/></svg>', rules: { video: 'pause', game: 'duck', mic: 'pause', call: 'pause', gps: 'duck', notif: 'duck' } },
  voiture:   { label: 'Voiture',   ic: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 16v-3l2-5h12l2 5v3"/><circle cx="7.5" cy="17" r="1.6" fill="currentColor"/><circle cx="16.5" cy="17" r="1.6" fill="currentColor"/></svg>', rules: { video: 'pause', game: 'keep',  mic: 'pause', call: 'pause', gps: 'duck', notif: 'keep' } },
  jeu:       { label: 'Jeu',       ic: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="1.5" y="6.5" width="21" height="11" rx="5.5"/><path d="M7 12H3M5 10v4"/></svg>', rules: { video: 'keep',  game: 'keep',  mic: 'duck',  call: 'pause', gps: 'keep', notif: 'keep' } },
  concentre: { label: 'Discret', ic: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><circle cx="12" cy="12" r="8"/></svg>', rules: { video: 'pause', game: 'pause', mic: 'pause', call: 'pause', gps: 'pause', notif: 'pause' } }
};
let currentProfile = 'maison';

function renderProfiles() {
  $('#profiles').innerHTML = Object.entries(PROFILES).map(([k, p]) =>
    `<button class="profile" data-profile="${k}" aria-pressed="${k === currentProfile}">${p.ic}${p.label}</button>`).join('');
  $('#profiles').querySelectorAll('.profile').forEach((b) => {
    b.addEventListener('click', () => {
      currentProfile = b.dataset.profile;
      const pr = PROFILES[currentProfile];
      SOURCES.forEach((s) => { s.rule = pr.rules[s.id]; });
      renderProfiles(); renderRules(); renderSimButtons();
      log(`Profil <b>${pr.label}</b> appliqué — 6 règles mises à jour`);
    });
  });
}

/* Si une règle est modifiée à la main, le profil devient « Personnalisé » */
function syncProfile() {
  const match = Object.keys(PROFILES).find((k) =>
    SOURCES.every((s) => PROFILES[k].rules[s.id] === s.rule));
  currentProfile = match || null;
  $('#profiles').querySelectorAll('.profile').forEach((b) =>
    b.setAttribute('aria-pressed', String(b.dataset.profile === currentProfile)));
}

let playing = true;
let activeTimer = null;
let activeSource = null;
let activeRule = null;
let FADE = 400;
let volRaf = null;
let volNow = 78;

/* -------- navigation entre écrans -------- */
const TAB_OF = {
  player: 'player', library: 'library', playlists: 'playlists',
  settings: 'settings', focus: 'settings', queue: 'settings', output: 'settings'
};

function show(name) {
  document.querySelectorAll('.screen').forEach((s) => s.classList.toggle('is-active', s.dataset.screen === name));
  const tab = TAB_OF[name] || 'player';
  document.querySelectorAll('.nav-item').forEach((x) => x.classList.toggle('is-on', x.dataset.go === tab));
  updateMiniplayer();
}

document.querySelectorAll('.nav-item').forEach((b) => {
  b.addEventListener('click', () => show(b.dataset.go));
});
document.querySelectorAll('[data-go-screen]').forEach((b) => {
  b.addEventListener('click', () => show(b.dataset.goScreen));
});

function updateMiniplayer() {
  const active = document.querySelector('.screen.is-active')?.dataset.screen;
  $('#miniplayer').hidden = active === 'player';
  const label = playing
    ? (activeRule === 'duck' ? 'Lecture · volume baissé' : 'Lecture · 78 %')
    : 'En pause';
  $('#miniState').textContent = label;
  $('#miniIcon').innerHTML = playing
    ? '<path d="M7 5h3.4v14H7zM13.6 5H17v14h-3.4z"/>'
    : '<path d="M8 5v14l11-7z"/>';
  $('#miniPlay').setAttribute('aria-label', playing ? 'Pause' : 'Lecture');
}

function goScreen(name) { show(name); }

/* -------- écran Focus audio : les règles -------- */
function renderRules() {
  $('#rulesList').innerHTML = SOURCES.map((s) => `
    <div class="rule">
      <div class="rule-head">
        <span class="rule-ic">${IC[s.id]}</span>
        <div class="row-txt"><strong>${s.label}</strong><span>${s.app}</span></div>
      </div>
      <div class="seg" role="group" aria-label="Comportement pour ${s.label}">
        <button data-src="${s.id}" data-act="pause" aria-pressed="${s.rule === 'pause'}">Pause</button>
        <button data-src="${s.id}" data-act="duck"  aria-pressed="${s.rule === 'duck'}">Baisser</button>
        <button data-src="${s.id}" data-act="keep"  aria-pressed="${s.rule === 'keep'}">Ignorer</button>
      </div>
    </div>`).join('');

  $('#rulesList').querySelectorAll('.seg button').forEach((b) => {
    b.addEventListener('click', () => {
      const src = SOURCES.find((s) => s.id === b.dataset.src);
      src.rule = b.dataset.act;
      b.parentElement.querySelectorAll('button').forEach((x) => x.setAttribute('aria-pressed', String(x === b)));
      renderSimButtons();
      syncProfile();
      log(`Règle modifiée — <b>${src.label}</b> : ${ACTS[src.rule].name.toLowerCase()}`);
    });
  });
}

/* -------- boutons du simulateur -------- */
function renderSimButtons() {
  $('#simBtns').innerHTML = SOURCES.map((s) => `
    <button class="sim-btn" data-play="${s.id}">
      <span class="sb-ic">${IC[s.id]}</span>
      <span><b>${s.label}</b><small>${ACTS[s.rule].short}</small></span>
    </button>`).join('');
  $('#simBtns').querySelectorAll('.sim-btn').forEach((b) => {
    b.addEventListener('click', () => trigger(b.dataset.play, b));
  });
}

/* -------- moteur d'état -------- */
function setState(act, why) {
  const a = ACTS[act];
  $('#stateLed').className = 'state-led ' + a.led;
  $('#stateText').textContent = act === 'pause' && !playing ? a.state : a.state;
  $('#stateWhy').textContent = why;
  animateVol(a.vol, act === 'duck');
  const cover = $('#cover');
  cover.classList.toggle('is-paused', act === 'pause');
  cover.classList.toggle('is-ducked', act === 'duck');
  $('#coverEq').classList.toggle('is-off', act === 'pause');
  setPlayIcon(act !== 'pause');
  updateMiniplayer();
}

function setPlayIcon(isPlaying) {
  playing = isPlaying;
  $('#playIcon').innerHTML = isPlaying
    ? '<path d="M7 5h3.4v14H7zM13.6 5H17v14h-3.4z"/>'
    : '<path d="M8 5v14l11-7z"/>';
  $('#playBtn').setAttribute('aria-label', isPlaying ? 'Pause' : 'Lecture');
}

function idle() {
  activeSource = null;
  activeRule = null;
  $('#interrupt').hidden = true;
  document.querySelectorAll('.sim-btn').forEach((b) => b.classList.remove('is-live'));
  setState('keep', 'Aucune autre application ne demande le son.');
  $('#focusChipText').textContent = 'Focus audio actif · 6 règles';
  updateMiniplayer();
}

function trigger(id, btn, over) {
  const s = SOURCES.find((x) => x.id === id);
  const rule = over ? over.rule : s.rule;
  const who = over ? over.app : s.label;
  const act = ACTS[rule];
  clearTimeout(activeTimer);
  activeSource = id;
  activeRule = rule;
  goScreen('player');

  document.querySelectorAll('.sim-btn').forEach((b) => b.classList.remove('is-live'));
  if (btn) btn.classList.add('is-live');

  const tone = rule === 'pause' ? 'pause' : rule === 'duck' ? 'duck' : 'keep';
  const int = $('#interrupt');
  int.hidden = false;
  $('#intIcon').innerHTML = IC[id];
  $('#intIcon').style.background = `var(--color-${tone === 'keep' ? 'primary' : tone}-soft)`;
  $('#intIcon').style.color = `var(--color-${tone === 'keep' ? 'primary' : tone})`;
  $('#intTitle').textContent = over
    ? `${over.app} — exception`
    : { video: 'Vidéo détectée', game: 'Jeu au premier plan', mic: 'Micro actif', call: 'Appel entrant', gps: 'Instruction GPS', notif: 'Notification sonore' }[id];
  $('#intSub').textContent = {
    pause: `Musique en pause — reprise en fondu de ${FADE} ms`,
    duck: 'Volume descendu à 22 % puis remonté',
    keep: 'Tikowiko garde le son — les deux sources cohabitent'
  }[rule];

  setState(rule, {
    pause: `${who} a pris le focus audio exclusif. Position mémorisée, fondu de ${FADE} ms.`,
    duck: `${who} demande un focus temporaire : la musique se baisse sans s'arrêter.`,
    keep: `${who} a demandé le focus, Tikowiko l'a refusé selon ta règle : la lecture continue.`
  }[rule]);
  $('#focusChipText').textContent = `${who} · ${act.name.toLowerCase()}`;

  log(`<b>${who}</b> demande le focus → ${act.name.toLowerCase()}${over ? ' <i>(exception d\'application)</i>' : ''}`);
  activeTimer = setTimeout(() => {
    if (activeSource !== id) return;
    log(`Fin de l'interruption <b>${who}</b> → ${rule === 'keep' ? 'aucun changement' : 'reprise à 78 %'}`);
    idle();
  }, s.dur);
}

/* -------- journal -------- */
function log(msg) {
  const ul = $('#log');
  ul.querySelector('.log-empty')?.remove();
  const now = new Date();
  const t = now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const li = document.createElement('li');
  li.innerHTML = `<span class="t">${t}</span><span class="m">${msg}</span>`;
  ul.prepend(li);
  while (ul.children.length > 8) ul.lastElementChild.remove();
}

/* -------- lecture / pause manuelle -------- */
$('#playBtn').addEventListener('click', () => {
  setPlayIcon(!playing);
  $('#coverEq').classList.toggle('is-off', !playing);
  $('#cover').classList.toggle('is-paused', !playing);
  if (!activeSource) {
    $('#stateText').textContent = playing ? 'Lecture · volume 78 %' : 'Pause · commande manuelle';
    $('#stateWhy').textContent = playing ? 'Aucune autre application ne demande le son.' : 'Mise en pause depuis le lecteur.';
    $('#stateLed').className = 'state-led' + (playing ? '' : ' led-pause');
  }
  updateMiniplayer();
  log(playing ? 'Lecture reprise <b>manuellement</b>' : 'Pause <b>manuelle</b> depuis le lecteur');
});

$('#miniPlay').addEventListener('click', () => $('#playBtn').click());

/* -------- sélection de la sortie audio -------- */
document.querySelectorAll('.out').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.out').forEach((b) => {
      b.classList.toggle('is-on', b === btn);
      b.querySelector('.out-check')?.remove();
    });
    const chk = document.createElement('span');
    chk.className = 'out-check'; chk.textContent = '✓';
    btn.appendChild(chk);
    log(`Sortie audio → <b>${btn.querySelector('strong').textContent}</b>`);
  });
});
document.querySelectorAll('#sleepChips .chip').forEach((c) => {
  c.addEventListener('click', () => {
    document.querySelectorAll('#sleepChips .chip').forEach((x) => x.classList.toggle('is-on', x === c));
    log(`Minuteur de sommeil → <b>${c.textContent}</b>`);
  });
});

/* -------- scénario automatique -------- */
const SCENARIO = ['video', 'game', 'mic', 'gps'];
let scenarioTimers = [];
$('#scenarioBtn').addEventListener('click', () => {
  const btn = $('#scenarioBtn');
  scenarioTimers.forEach(clearTimeout);
  scenarioTimers = [];
  btn.disabled = true;
  btn.textContent = 'Scénario en cours…';
  let t = 0;
  SCENARIO.forEach((id, i) => {
    scenarioTimers.push(setTimeout(() => {
      trigger(id, document.querySelector(`.sim-btn[data-play="${id}"]`));
    }, t));
    t += (SOURCES.find((x) => x.id === id).dur + 900);
    if (i === SCENARIO.length - 1) {
      scenarioTimers.push(setTimeout(() => {
        btn.disabled = false;
        btn.textContent = 'Rejouer le scénario';
        log('Scénario terminé — lecteur au repos');
      }, t));
    }
  });
});

/* -------- interrupteurs décoratifs -------- */
document.querySelectorAll('.sw[role="switch"]').forEach((sw) => {
  const toggle = () => {
    const on = sw.classList.toggle('is-on');
    sw.setAttribute('aria-checked', String(on));
  };
  sw.addEventListener('click', toggle);
  sw.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); } });
});

/* -------- barre de progression animée -------- */
(function seek() {
  let sec = 138;
  let total = 384;
  document.addEventListener('track-change', (e) => { sec = 0; total = e.detail; });
  setInterval(() => {
    if (!playing) return;
    sec = (sec + 1) % total;
    const pct = (sec / total) * 100;
    $('#seekFill').style.width = pct + '%';
    $('#seekKnob').style.left = pct + '%';
    $('#tCur').textContent = String(Math.floor(sec / 60)).padStart(2, '0') + ':' + String(sec % 60).padStart(2, '0');
  }, 1000);
})();

/* -------- init -------- */
renderProfiles();
renderRules();
renderSimButtons();
idle();
updateMiniplayer();

/* ================= ITÉRATION 3 ================= */

/* -------- volume animé -------- */
function animateVol(target, ducked) {
  cancelAnimationFrame(volRaf);
  const fill = $('#volFill');
  const val = $('#volVal');
  fill.classList.toggle('is-ducked', !!ducked);
  const from = volNow;
  const t0 = performance.now();
  const dur = Math.max(FADE, 260);
  const step = (t) => {
    const k = Math.min((t - t0) / dur, 1);
    const e = 1 - Math.pow(1 - k, 3);
    volNow = from + (target - from) * e;
    fill.style.width = volNow + '%';
    val.textContent = Math.round(volNow);
    if (k < 1) volRaf = requestAnimationFrame(step);
  };
  volRaf = requestAnimationFrame(step);
}

/* -------- durée du fondu -------- */
document.querySelectorAll('#fadeChips .chip').forEach((c) => {
  c.addEventListener('click', () => {
    FADE = Number(c.dataset.fade);
    document.querySelectorAll('#fadeChips .chip').forEach((x) => {
      const on = x === c;
      x.classList.toggle('is-on', on);
      x.setAttribute('aria-pressed', String(on));
    });
    log(`Fondu réglé sur <b>${FADE} ms</b>`);
  });
});

/* -------- bibliothèque -------- */
const TRACKS = [
  { t: "11 ans d'amour Mix",  ar: 'tikowikodu84', al: "Nuit d'Or",       f: 'FLAC 24 bit · local', d: '06:24', c: 'gold-a.jpg', dir: 'Music/tikowikodu84' },
  { t: "Nuit d'Or",           ar: 'tikowikodu84', al: "Nuit d'Or",       f: 'FLAC',                d: '04:52', c: 'gold-a.jpg', dir: 'Music/tikowikodu84' },
  { t: 'Vinyle Doré',         ar: 'Maison Or',    al: 'Sillons',         f: 'MP3 320',             d: '03:58', c: 'gold-b.jpg', dir: 'Music/Maison Or' },
  { t: 'Sillons',             ar: 'Maison Or',    al: 'Sillons',         f: 'FLAC',                d: '05:16', c: 'gold-b.jpg', dir: 'Music/Maison Or' },
  { t: 'Basses Cuivrées',     ar: 'Atelier Noir', al: 'Cuivre & Nuit',   f: 'OPUS',                d: '04:31', c: 'gold-c.jpg', dir: 'Music/Atelier Noir' },
  { t: 'Cuivre & Nuit',       ar: 'Atelier Noir', al: 'Cuivre & Nuit',   f: 'FLAC 24 bit',         d: '06:02', c: 'gold-c.jpg', dir: 'Music/Atelier Noir' },
  { t: 'Scène Royale',        ar: 'Famille Tiko', al: 'Édition Premium', f: 'FLAC',                d: '05:07', c: 'gold-d.jpg', dir: 'Music/Famille Tiko' },
  { t: 'Couronne',            ar: 'Famille Tiko', al: 'Édition Premium', f: 'MP3 320',             d: '03:44', c: 'gold-d.jpg', dir: 'Music/Famille Tiko' }
];
let libView = 'titres';
let libQuery = '';
let current = 0;

const thumb = (tr, cls = 'mini') =>
  tr.c ? `<img class="${cls}" src="${tr.c}" alt="" width="38" height="38" />`
       : `<span class="${cls} ${tr.k}" aria-hidden="true"></span>`;

function libMatches(tr) {
  const q = libQuery.trim().toLowerCase();
  if (!q) return true;
  return [tr.t, tr.ar, tr.al, tr.dir].join(' ').toLowerCase().includes(q);
}

function renderLibrary() {
  const list = $('#libList');
  const hits = TRACKS.map((tr, i) => ({ tr, i })).filter(({ tr }) => libMatches(tr));
  $('#libCount').textContent = libQuery
    ? `${hits.length} résultat${hits.length > 1 ? 's' : ''}`
    : `${TRACKS.length} titres`;

  if (!hits.length) {
    list.innerHTML = `<li class="list-empty">Aucun titre ne correspond à « ${libQuery} ».<span>La recherche porte sur le titre, l'artiste, l'album et le dossier.</span></li>`;
    return;
  }

  if (libView === 'titres') {
    list.innerHTML = hits.map(({ tr, i }) => `
      <li class="row${i === current ? ' is-playing' : ''}" data-track="${i}" tabindex="0" role="button">
        ${thumb(tr)}
        <div class="row-txt"><strong>${tr.t}</strong><span>${tr.ar} · ${tr.f.split(' · ')[0]}</span></div>
        ${i === current ? '<span class="eq-mini" aria-hidden="true"><i></i><i></i><i></i></span>' : `<span class="dur">${tr.d}</span>`}
      </li>`).join('');
  } else {
    const key = libView === 'albums' ? 'al' : libView === 'artistes' ? 'ar' : 'dir';
    const groups = new Map();
    hits.forEach(({ tr, i }) => {
      if (!groups.has(tr[key])) groups.set(tr[key], []);
      groups.get(tr[key]).push({ tr, i });
    });
    list.innerHTML = [...groups.entries()].map(([name, items]) => `
      <li class="row grp" data-track="${items[0].i}" tabindex="0" role="button">
        ${thumb(items[0].tr)}
        <div class="row-txt"><strong>${name}</strong><span>${items.length} titre${items.length > 1 ? 's' : ''}${libView === 'albums' ? ' · ' + items[0].tr.ar : ''}</span></div>
        <svg class="row-go" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>
      </li>`).join('');
  }

  list.querySelectorAll('[data-track]').forEach((li) => {
    const go = () => playTrack(Number(li.dataset.track));
    li.addEventListener('click', go);
    li.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); } });
  });
}

function playTrack(i) {
  current = i;
  const tr = TRACKS[i];
  const src = tr.c || 'gold-a.jpg';
  $('#coverImg').src = src;
  $('#coverImg').alt = `Pochette de l'album ${tr.al}`;
  $('#trackTitle').textContent = tr.t;
  $('#trackArtist').textContent = tr.ar;
  $('#trackFmt').textContent = tr.f;
  $('#tTot').textContent = tr.d;
  $('#miniCover').src = src;
  $('#miniTitle').textContent = tr.t;
  $('#npCover').src = src;
  $('#npTitle').textContent = tr.t;
  $('#npArtist').textContent = `${tr.ar} · en cours`;
  setPlayIcon(true);
  $('#coverEq').classList.remove('is-off');
  $('#cover').classList.remove('is-paused');
  const [mm, ss] = tr.d.split(':').map(Number);
  document.dispatchEvent(new CustomEvent('track-change', { detail: mm * 60 + ss }));
  renderLibrary();
  goScreen('player');
  log(`Lecture de <b>${tr.t}</b> — ${tr.ar} · ${tr.f}`);
}

/* vues + recherche */
document.querySelectorAll('#libViews .chip').forEach((c) => {
  c.addEventListener('click', () => {
    libView = c.dataset.view;
    document.querySelectorAll('#libViews .chip').forEach((x) => {
      const on = x === c;
      x.classList.toggle('is-on', on);
      x.setAttribute('aria-pressed', String(on));
    });
    renderLibrary();
  });
});
$('#searchBtn').addEventListener('click', () => {
  show('library');
  const w = $('#searchWrap');
  const open = w.hidden;
  w.hidden = !open;
  $('#searchBtn').setAttribute('aria-expanded', String(open));
  if (open) $('#searchInput').focus();
  else { libQuery = ''; $('#searchInput').value = ''; renderLibrary(); }
});
$('#searchInput').addEventListener('input', (e) => { libQuery = e.target.value; renderLibrary(); });
$('#searchClear').addEventListener('click', () => {
  libQuery = ''; $('#searchInput').value = ''; $('#searchInput').focus(); renderLibrary();
});

/* -------- exceptions par application -------- */
const EXC = [
  { app: 'YouTube',   src: 'video', rule: 'pause', note: 'Catégorie vidéo' },
  { app: 'Instagram', src: 'video', rule: 'duck',  note: 'Stories — juste baisser' },
  { app: 'Discord',   src: 'mic',   rule: 'keep',  note: 'Vocal entre amis' },
  { app: 'Waze',      src: 'gps',   rule: 'duck',  note: 'Instructions courtes' },
  { app: 'Duolingo',  src: 'notif', rule: 'pause', note: 'Leçons parlées' }
];
const ORDER = ['pause', 'duck', 'keep'];
const EXC_LABEL = { pause: 'Pause', duck: 'Baisser', keep: 'Ignorer' };

function renderExc() {
  const custom = EXC.filter((e) => SOURCES.find((s) => s.id === e.src)?.rule !== e.rule).length;
  $('#excCount').textContent = custom ? `${custom} exception${custom > 1 ? 's' : ''}` : 'aucune exception';
  $('#excList').innerHTML = EXC.map((e, i) => {
    const base = SOURCES.find((s) => s.id === e.src)?.rule;
    const diff = base !== e.rule;
    return `
    <li class="exc-row">
      <span class="exc-ic">${IC[e.src]}</span>
      <div class="row-txt"><strong>${e.app}${diff ? '<b class="exc-flag">exception</b>' : ''}</strong><span>${e.note}</span></div>
      <button class="exc-pill c-${e.rule}" data-exc="${i}" aria-label="Changer la règle de ${e.app}, actuellement ${ACTS[e.rule].name}">${EXC_LABEL[e.rule]}</button>
      <button class="exc-test" data-test="${i}" aria-label="Simuler une interruption depuis ${e.app}">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
      </button>
    </li>`;
  }).join('');

  $('#excList').querySelectorAll('[data-exc]').forEach((b) => {
    b.addEventListener('click', () => {
      const e = EXC[Number(b.dataset.exc)];
      e.rule = ORDER[(ORDER.indexOf(e.rule) + 1) % 3];
      renderExc();
      log(`<b>${e.app}</b> → ${ACTS[e.rule].name.toLowerCase()}`);
    });
  });
  $('#excList').querySelectorAll('[data-test]').forEach((b) => {
    b.addEventListener('click', () => {
      const e = EXC[Number(b.dataset.test)];
      trigger(e.src, document.querySelector(`.sim-btn[data-play="${e.src}"]`), e);
    });
  });
}

/* garder les exceptions à jour quand les règles changent */
const _renderRules = renderRules;
renderRules = function () { _renderRules(); renderExc(); };
const _renderProfiles = renderProfiles;
renderProfiles = function () { _renderProfiles(); if ($('#excList')) renderExc(); };

renderLibrary();
renderExc();

/* ================= ÉDITION OR — thèmes, playlists, file d'attente ================= */

const MODES = [
  { id: 'classique', label: 'Classique', note: 'Signal neutre, aucune coloration',
    ic: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="2.2"/></svg>' },
  { id: 'vinyle', label: 'Vinyle', note: 'Chaleur analogique et souffle léger',
    ic: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.3" fill="currentColor"/></svg>' },
  { id: 'basses', label: 'Basses+', note: 'Grave renforcé à partir de 80 Hz',
    ic: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M3 12h3l2.5-6 3 12 3-9 2 3h4.5"/></svg>' },
  { id: 'nuit', label: 'Nuit', note: 'Dynamique compressée pour écouter bas',
    ic: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"><path d="M20 13.2A8.4 8.4 0 1 1 10.8 4a6.6 6.6 0 0 0 9.2 9.2z"/></svg>' },
  { id: 'scene', label: 'Scène', note: 'Stéréo élargie, effet salle',
    ic: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M4 18V9M8 18V5M12 18v-7M16 18V7M20 18v-5"/></svg>' }
];
let curMode = 'classique';

function renderModes() {
  $('#modeRow').innerHTML = MODES.map((m) => `
    <button class="mode-card${m.id === curMode ? ' is-on' : ''}" data-mode="${m.id}" aria-pressed="${m.id === curMode}">
      ${m.ic}<span>${m.label}</span>
    </button>`).join('');
  $('#modeDots').innerHTML = MODES.map((m) => `<i class="${m.id === curMode ? 'is-on' : ''}"></i>`).join('');
  $('#modeRow').querySelectorAll('.mode-card').forEach((b) => {
    b.addEventListener('click', () => {
      curMode = b.dataset.mode;
      const m = MODES.find((x) => x.id === curMode);
      renderModes();
      log(`Mode d'écoute <b>${m.label}</b> — ${m.note.toLowerCase()}`);
    });
  });
}

/* -------- playlists -------- */
const PLAYLISTS = [
  { n: 'Nuit d\'Or', k: [0, 1, 5], note: 'Écoute du soir' },
  { n: 'Sillons & vinyles', k: [2, 3], note: 'Chaleur analogique' },
  { n: 'Scène Premium', k: [6, 7, 4], note: 'Volume haut, casque' },
  { n: 'Trajet Marseille', k: [1, 4, 6, 0], note: 'Hors-ligne, voiture' }
];

function renderPlaylists() {
  $('#plList').innerHTML = PLAYLISTS.map((p, i) => {
    const cov = TRACKS[p.k[0]].c;
    const secs = p.k.reduce((a, j) => { const [m, s] = TRACKS[j].d.split(':').map(Number); return a + m * 60 + s; }, 0);
    const mins = Math.round(secs / 60);
    return `<li class="row" data-pl="${i}" tabindex="0" role="button">
      <img class="mini big" src="${cov}" alt="" width="46" height="46" />
      <div class="row-txt"><strong>${p.n}</strong><span>${p.k.length} titres · ${mins} min · ${p.note}</span></div>
      <svg class="row-go" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>
    </li>`;
  }).join('');
  const hint = $('#plHint')?.querySelector('.row-txt span');
  if (hint) hint.textContent = `${PLAYLISTS.length} playlists · stockées en local`;
  $('#plList').querySelectorAll('[data-pl]').forEach((li) => {
    const go = () => {
      const p = PLAYLISTS[Number(li.dataset.pl)];
      log(`Playlist <b>${p.n}</b> lancée — ${p.k.length} titres`);
      playTrack(p.k[0]);
    };
    li.addEventListener('click', go);
    li.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); } });
  });
}

$('#newPl')?.addEventListener('click', () => {
  const n = PLAYLISTS.length + 1;
  PLAYLISTS.push({ n: `Nouvelle playlist ${n}`, k: [0], note: 'À compléter' });
  renderPlaylists();
  log(`Playlist <b>Nouvelle playlist ${n}</b> créée`);
});

/* -------- file d'attente -------- */
function renderQueue() {
  const order = TRACKS.map((_, i) => i).filter((i) => i !== current).slice(0, 6);
  $('#queueList').innerHTML = order.map((i) => {
    const tr = TRACKS[i];
    return `<li class="row" data-q="${i}" tabindex="0" role="button">
      <span class="grip" aria-hidden="true"><i></i><i></i><i></i></span>
      <img class="mini" src="${tr.c}" alt="" width="38" height="38" />
      <div class="row-txt"><strong>${tr.t}</strong><span>${tr.ar}</span></div>
      <span class="dur">${tr.d}</span>
    </li>`;
  }).join('');
  const lbl = document.querySelector('.screen[data-screen="queue"] .q-label');
  if (lbl) {
    const secs = order.reduce((a, i) => { const [m, x] = TRACKS[i].d.split(':').map(Number); return a + m * 60 + x; }, 0);
    lbl.textContent = `À suivre — ${order.length} titres · ${Math.round(secs / 60)} min`;
  }
  $('#queueList').querySelectorAll('[data-q]').forEach((li) => {
    const go = () => playTrack(Number(li.dataset.q));
    li.addEventListener('click', go);
    li.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); } });
  });
}

/* -------- coup de cœur -------- */
$('#likeBtn')?.addEventListener('click', () => {
  const on = $('#likeBtn').getAttribute('aria-pressed') !== 'true';
  $('#likeBtn').setAttribute('aria-pressed', String(on));
  log(on ? `<b>${TRACKS[current].t}</b> ajouté aux coups de cœur` : `<b>${TRACKS[current].t}</b> retiré des coups de cœur`);
});

/* -------- résumés dans Paramètres -------- */
function syncSettings() {
  const p = currentProfile ? PROFILES[currentProfile].label : 'Personnalisé';
  if ($('#setFocusVal')) $('#setFocusVal').textContent = p;
  const out = document.querySelector('.out.is-on strong');
  if ($('#setOutVal') && out) $('#setOutVal').textContent = out.textContent.split(' · ')[0];
}

document.querySelectorAll('.out').forEach((b) => b.addEventListener('click', syncSettings));
$('#profiles').addEventListener('click', () => setTimeout(syncSettings, 0));
$('#rulesList').addEventListener('click', () => setTimeout(syncSettings, 0));

/* -------- menu (ouvre les paramètres) -------- */
$('#menuBtn')?.addEventListener('click', () => show('settings'));

/* -------- rafraîchir la file quand le titre change -------- */
const _playTrack = playTrack;
playTrack = function (i) { _playTrack(i); renderQueue(); };

renderModes();
renderPlaylists();
renderQueue();
syncSettings();
show('player');
